import java.awt.*;
class mythread8 extends Thread
{
int x1,y1;
mythread8(int x1,int y1)
{
this.x1=x1;
this.y1=y1;
}
public void run()
{
int i;
for(i=x1;i>=-30;i=i-30)
{
try
{
if(i>=210&&i<=250&&y1>=265&&y1<=305)
i=-20;
if(i>=650&&i<=690&&y1>=345&&y1<=385)
i=-20;
if(i>=1150&&i<=1190&&y1>=185&&y1<=305)
i=-20;
if(i>=170&&i<=210&&y1>=185&&y1<=305)
i=-20;
if(i>=1190&&i<=1230&&y1>=505&&y1<=585)
i=-20;
if(i>=1070&&i<=1110&&y1>=505&&y1<=585)
i=-20;
if(i>=250&&i<=290&&y1>=505&&y1<=585)
i=-20;
if(i>=130&&i<=170&&y1>=505&&y1<=585)
i=-20;
my.b6.setBounds(i-10,y1+15,10,10);
Thread.sleep(50);
if(i>=my.x1+10&&i<=(my.x1+50)&&y1>=my.y1-15&&y1<=(my.y1+25))
{
System.out.println("PLAYER2 WINS");
System.exit(0);
}
}
catch(Exception e)
{}

}


}
}