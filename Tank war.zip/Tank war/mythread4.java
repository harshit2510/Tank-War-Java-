import java.awt.*;
class mythread4 extends Thread
{
int x,y;
mythread4(int x,int y)
{
this.x=x;
this.y=y;
}
public void run()
{
int i;
for(i=x;i>=-30;i=i-30)
{
try
{if(i>=210&&i<=250&&y>=265&&y<=305)
i=-20;
if(i>=650&&i<=690&&y>=345&&y<=385)
i=-20;
if(i>=1150&&i<=1190&&y>=185&&y<=305)
i=-20;
if(i>=170&&i<=210&&y>=185&&y<=305)
i=-20;
if(i>=1190&&i<=1230&&y>=505&&y<=585)
i=-20;
if(i>=1070&&i<=1110&&y>=505&&y<=585)
i=-20;
if(i>=250&&i<=290&&y>=505&&y<=585)
i=-20;
if(i>=130&&i<=170&&y>=505&&y<=585)
i=-20;
my.b5.setBounds(i-10,y+15,10,10);
Thread.sleep(50);
if(i>=my.x2+10&&i<=(my.x2+50)&&y>=my.y2-15&&y<=(my.y2+25))
{
System.out.println("PLAYER1 WINS");
System.exit(0);
}
}
catch(Exception e)
{}

}

}
}