import java.awt.*;
class mythread7 extends Thread
{
int x1,y1;
mythread7(int x1,int y1)
{
this.x1=x1;
this.y1=y1;
}
public void run()
{
int i;
for(i=y1;i>=-30;i=i-30)
{
try
{
if(x1>=625&&x1<=665&&i>=360&&i<=400)
i=-20;
if(x1>=145&&x1<=185&&i>=200&&i<=320)
i=-20;
if(x1>=1125&&x1<=1165&&i>=200&&i<=320)
i=-20;
if(x1>=105&&x1<=145&&i>=520&&i<=600)
i=-20;
if(x1>=225&&x1<=265&&i>=520&&i<=600)
i=-20;
if(x1>=1045&&x1<=1085&&i>=520&&i<=600)
i=-20;
if(x1>=1165&&x1<=1205&&i>=520&&i<=600)
i=-20;
my.b6.setBounds(x1+15,i,10,10);
Thread.sleep(50);
if(x1>=my.x1-15&&x1<=(my.x1+25)&&i>=my.y1&&i<=(my.y1+40))
{
System.out.println("PLAYER2 WINS");
System.exit(0);
}
}
catch(Exception e)
{}

}

}
}