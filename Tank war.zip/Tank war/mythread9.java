import java.awt.*;
class mythread9 extends Thread
{
int x1,y1;
mythread9(int x1,int y1)
{
this.x1=x1;
this.y1=y1;
}
public void run()
{
int i;
for(i=x1;i<=1350;i=i+30)
{
try
{
if(i>=150&&i<=190&&y1>=265&&y1<=305)
i=1340;
if(i>=590&&i<=630&&y1>=345&&y1<=385)
i=1340;
if(i>=1090&&i<=1130&&y1>=185&&y1<=315)
i=1340;
if(i>=110&&i<=150&&y1>=185&&y1<=315)
i=1340;
if(i>=1130&&i<=1170&&y1>=505&&y1<=585)
i=1340;
if(i>=1010&&i<=1050&&y1>=505&&y1<=585)
i=1340;
if(i>=190&&i<=130&&y1>=505&&y1<=585)
i=1340;
if(i>=70&&i<=110&&y1>=505&&y1<=585)
i=1340;
my.b6.setBounds(i+50,y1+15,10,10);
Thread.sleep(50);
if(i>=my.x1-50&&i<=(my.x1-10)&&y1>=my.y1-15&&y1<=(my.y1+25))
{
System.out.println("PLAYER2 WINS");
System.exit(0);
}
}
catch(Exception e)
{}
}

}
}