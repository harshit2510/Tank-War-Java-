import java.awt.*;
class mythread10 extends Thread
{
char c1;
mythread10(char c1)
{
this.c1=c1;
}
public void run()
{
my.b2.setBounds(my.x2,my.y2,40,40);
if(c1=='R')
my.b4.setBounds(my.x2+40,my.y2+15,10,10);
if(c1=='L')
my.b4.setBounds(my.x2-10,my.y2+15,10,10);
if(c1=='U')
my.b4.setBounds(my.x2+15,my.y2-10,10,10);
if(c1=='D')
my.b4.setBounds(my.x2+15,my.y2+40,10,10);
}
}