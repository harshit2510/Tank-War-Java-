import java.awt.*;
import javax.swing.*;
import java.io.*;
class mybutton extends Button
{
mybutton(String str)
{
super(str);
}
public void paint(Graphics g)
{


}
}