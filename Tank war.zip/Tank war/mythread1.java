import java.awt.*;
class mythread1 extends Thread
{
int x,y;
mythread1(int x,int y)
{
this.x=x;
this.y=y;
}
public void run()
{
int i;
for(i=y;i>=-30;i=i-30)
{
try
{
if(x>=185&&x<=225&&i>=280&&i<=320)
i=-20;
if(x>=145&&x<=185&&i>=200&&i<=320)
i=-20;
if(x>=1125&&x<=1165&&i>=200&&i<=320)
i=-20;
if(x>=105&&x<=145&&i>=520&&i<=600)
i=-20;
if(x>=225&&x<=265&&i>=520&&i<=600)
i=-20;
if(x>=1045&&x<=1085&&i>=520&&i<=600)
i=-20;
if(x>=1165&&x<=1205&&i>=520&&i<=600)
i=-20;
if(x>=625&&x<=665&&i>=360&&i<=400)
i=-20;
my.b5.setBounds(x+15,i,10,10);
Thread.sleep(50);
if(x>=my.x2-15&&x<=(my.x2+25)&&i>=my.y2&&i<=(my.y2+40))
{
System.out.println("PLAYER1 WINS");
System.exit(0);
}
}
catch(Exception e)
{}


}

}
}