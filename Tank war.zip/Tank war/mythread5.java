import java.awt.*;
class mythread5 extends Thread
{
int x,y;
mythread5(int x,int y)
{
this.x=x;
this.y=y;
}
public void run()
{
int i;
for(i=x;i<=1350;i=i+30)
{
try
{
if(i>=150&&i<=190&&x>=265&&y<=305)
i=1340;
if(i>=590&&i<=630&&y>=345&&y<=385)
i=1340;
if(i>=1090&&i<=1130&&y>=185&&y<=315)
i=1340;
if(i>=110&&i<=150&&y>=185&&y<=315)
i=1340;
if(i>=1130&&i<=1170&&y>=505&&y<=585)
i=1340;
if(i>=1010&&i<=1050&&y>=505&&y<=585)
i=1340;
if(i>=190&&i<=130&&y>=505&&y<=585)
i=1340;
if(i>=70&&i<=110&&y>=505&&y<=585)
i=1340;
my.b5.setBounds(i+50,y+15,10,10);
Thread.sleep(50);
if(i>=my.x2-50&&i<=(my.x2-10)&&y>=my.y2-15&&y<=(my.y2+25))
{
System.out.println("PLAYER1 WINS");
System.exit(0);}
}
catch(Exception e)
{}

}

}
}