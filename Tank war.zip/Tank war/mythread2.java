import java.awt.*;
class mythread2 extends Thread
{
char c;
mythread2(char c)
{
this.c=c;
}
public void run()
{
my.b1.setBounds(my.x1,my.y1,40,40);
if(c=='D')
my.b3.setBounds(my.x1+40,my.y1+15,10,10);
if(c=='A')
my.b3.setBounds(my.x1-10,my.y1+15,10,10);
if(c=='W')
my.b3.setBounds(my.x1+15,my.y1-10,10,10);
if(c=='S')
my.b3.setBounds(my.x1+15,my.y1+40,10,10);
}
}