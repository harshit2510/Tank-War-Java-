import java.awt.*;
class mythread6 extends Thread
{
int x1,y1;
mythread6(int x1,int y1)
{
this.x1=x1;
this.y1=y1;
}
public void run()
{
int i;
for(i=y1;i<=750;i=i+30)
{
try
{
if(x1>=185&&x1<=225&&i>=230&&i<=270)
i=740;
if(x1>=625&&x1<=665&&i>=310&&i<=350)
i=740;
if(x1>=145&&x1<=185&&i>=150&&i<=270)
i=740;
if(x1>=1125&&x1<=1165&&i>=150&&i<=270)
i=740;
if(x1>=105&&x1<=145&&i>=470&&i<=550)
i=740;
if(x1>=225&&x1<=265&&i>=470&&i<=550)
i=740;
if(x1>=1045&&x1<=1085&&i>=470&&i<=550)
i=740;
if(x1>=1165&&x1<=1205&&i>=470&&i<=550)
i=740;
my.b6.setBounds(x1+15,i+50,10,10);
Thread.sleep(50);
if(x1>=my.x1-15&&x1<=(my.x1+25)&&i>=my.y1-50&&i<=(my.y1-10))
{
System.out.println("PLAYER2 WINS");
System.exit(0);
}
}
catch(Exception e)
{}

}

}
}