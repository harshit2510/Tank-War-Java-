import java.awt.*;
class mythread3 extends Thread
{
int x,y;
mythread3(int x,int y)
{
this.x=x;
this.y=y;
}
public void run()
{
int i;
for(i=y;i<=750;i=i+30)
{
try
{
if(x>=185&&x<=225&&i>=230&&i<=270)
i=740;
if(x>=145&&x<=185&&i>=150&&i<=270)
i=740;
if(x>=1125&&x<=1165&&i>=150&&i<=270)
i=740;
if(x>=105&&x<=145&&i>=470&&i<=550)
i=740;
if(x>=225&&x<=265&&i>=470&&i<=550)
i=740;
if(x>=1045&&x<=1085&&i>=470&&i<=550)
i=740;
if(x>=1165&&x<=1205&&i>=470&&i<=550)
i=740;
if(x>=625&&x<=665&&i>=310&&i<=350)
i=740;
my.b5.setBounds(x+15,i+50,10,10);
Thread.sleep(50);
if(x>=my.x2-15&&x<=(my.x2+25)&&i>=my.y2-50&&i<=(my.y2-10))
{
System.out.println("PLAYER1 WINS");
System.exit(0);
}
}
catch(Exception e)
{}

}

}
}