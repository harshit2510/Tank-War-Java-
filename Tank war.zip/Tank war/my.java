import java.awt.*;
import java.awt.event.*;
import java.io.*;
import javax.swing.*;
class my extends Frame implements KeyListener 
{
static mybutton b1,b2,b3,b4,b5,b6,b7,b8,b9,b10,b22,b23;
static mybutton b11,b12,b13,b14,b15,b16,b17,b18,b19,b20,b21;
static int x1,y1,x2,y2,x3,y3,x4,y4,x5,y5,x6,y6;
char c1;
char c2;
char c3;
Label t1,t2;
public my()
{
c1='U';
c2='S';
c3='l';
x1=640;
y1=30;
x2=640;
y2=680;
x3=160;
y3=200;
x4=1140;
y4=200;
x5=160;
y5=520;
x6=1100;
y6=520;
t1=new Label();
t1.setText("PLAYER 1");
t2=new Label();
t2.setText("PLAYER 2");
b1=new mybutton("");
b2=new mybutton("");
b3=new mybutton("");
b4=new mybutton("");
b5=new mybutton("");
b6=new mybutton("");
b7=new mybutton("");
b8=new mybutton("");
b9=new mybutton("");
b10=new mybutton("");
b11=new mybutton("");
b12=new mybutton("");
b13=new mybutton("");
b14=new mybutton("");
b15=new mybutton("");
b16=new mybutton("");
b17=new mybutton("");
b18=new mybutton("");
b19=new mybutton("");
b20=new mybutton("");
b21=new mybutton("");
b22=new mybutton("");
b23=new mybutton("");
this.setSize(1320,720);
this.setLayout(null);
t1.setBounds(1220,y1,80,20);
t2.setBounds(1220,y2+20,80,20);
b1.setBounds(x1,y1,40,40);
b2.setBounds(x2,y2,40,40);
b3.setBounds(x1+15,y1+40,10,10);
b4.setBounds(x2+15,y2-10,10,10);
b7.setBounds(x3,y3,40,40);
b8.setBounds(x3,y3+40,40,40);
b9.setBounds(x3,y3+80,40,40);
b10.setBounds(x3+40,y3+80,40,40);
b11.setBounds(x4,y4,40,40);
b12.setBounds(x4,y4+40,40,40);
b13.setBounds(x4,y4+80,40,40);
b14.setBounds(x4-40,y4+80,40,40);
b15.setBounds(x1,360,40,40);
b16.setBounds(x5-40,y5,40,40);
b17.setBounds(x5+80,y5,40,40);
b18.setBounds(x6-40,y6,40,40);
b19.setBounds(x6+80,y6,40,40);
b20.setBounds(x5-40,y5+40,40,40);
b21.setBounds(x5+80,y5+40,40,40);
b22.setBounds(x6-40,y6+40,40,40);
b23.setBounds(x6+80,y6+40,40,40);
this.add(t1);
this.add(t2);
this.add(b1);
this.add(b2); 
this.add(b3);
this.add(b4);
this.add(b5);
this.add(b6);
this.add(b9);
this.add(b10); 
this.add(b7);
this.add(b8);
this.add(b11);
this.add(b12); 
this.add(b13);
this.add(b14);
this.add(b15);
this.add(b16); 
this.add(b17);
this.add(b18);
this.add(b19);
this.add(b20); 
this.add(b21);
this.add(b22);
this.add(b23);
this.setVisible(true);
this.setResizable(false);
b1.addKeyListener(this);
b2.addKeyListener(this);
b5.addKeyListener(this);
b3.addKeyListener(this);
b4.addKeyListener(this);
b6.addKeyListener(this);
}
public void keyReleased(KeyEvent e)
{
mythread2 ob;
mythread1 ob3;
mythread3 ob5;
mythread4 ob4;
mythread5 ob6;
mythread6 ob7;
mythread7 ob8;
mythread8 ob9;
mythread9 ob10;
mythread10 ob1;
char c=(char)e.getKeyCode();
int d=e.getKeyCode();

if(c=='A'||c=='W'||c=='D'||c=='S')
{
if(c=='D')
{
c2='D';
if((x1>=1140||x1<=1040)||(y1>=320||y1<=240))
if((x1<=550||x1>=680)||(y1<=320||y1>=400))
{
if((x1<120||x1>=200)||(y1<=160||y1>=320))
{
if((x1<1060||x1>=1180)||(y1<=160||y1>=320))
{
if((x1<80||x1>=160)||(y1<=480)||(y1>=600))
{
if((x1<980||x1>=1100)||(y1<=480)||(y1>=600))
{
if((x1<200||x1>=280)||(y1<=480)||(y1>=600))
{
if((x1<1040||x1>=1220)||(y1<=480)||(y1>=600))
{
x1=x1+40;
if(x1>=1310)
x1=-10;
}
}
}
}
}
}
}
}
if(c=='A')
{
c2='A';
if((x1>=280||x1<=120)||(y1>=320||y1<=240))
if((x1<=620||x1>=720)||(y1<=320||y1>=400))
{
if((x1<=120||x1>=240)||(y1<=160||y1>=320))
{
if((x1<=1100||x1>=1220)||(y1<=160||y1>=320))
{
if((x1<=80||x1>=200)||(y1<=480)||(y1>=600))
{
if((x1<=1020||x1>=1140)||(y1<=480)||(y1>=600))
{
if((x1<=200||x1>=320)||(y1<=480)||(y1>=600))
{
if((x1<=1040||x1>=1260)||(y1<=480)||(y1>=600))
{

x1=x1-40;
if(x1<-20)
x1=1300;
}
}
}
}
}
}
}
}
if(c=='W')
{
c2='W';
if((y1>=360||y1<=240)||(x1<=160||x1>=240))
if((y1>=360||y1<=240)||(x1<=1080||x1>=1180))
if((x1<=620||x1>=680)||(y1<=320||y1>=440))
{
if((x1<=120||x1>=200)||(y1>=360||y1<=160))
{
if((x1<=1100||x1>=1180)||(y1<=160||y1>=360))
{
if((x1<=80||x1>=160)||(y1<=480)||(y1>=660))
{
if((x1<=1020||x1>=1100)||(y1<=480)||(y1>=660))
{
if((x1<=200||x1>=380)||(y1<=480)||(y1>=660))
{
if((x1<=1140||x1>=1220)||(y1<=480)||(y1>=660))
{

y1=y1-40;
if(y1<-10)
y1=700;
}
}
}
}
}
}
}
}
if(c=='S')
{
c2='S';
if((y1>=320||y1<=200)||(x1<=160||x1>=240))
if((y1>=320||y1<=200)||(x1<=1080||x1>=1160))
if((x1<=620||x1>=680)||(y1<=280||y1>=400))
{
if((x1<=120||x1>=200)||(y1>=360||y1<=120))
{
if((x1<=1100||x1>=1180)||(y1<=120||y1>=360))
{
if((x1<=80||x1>=160)||(y1<=440)||(y1>=660))
{
if((x1<=1020||x1>=1100)||(y1<=440)||(y1>=660))
{
if((x1<=200||x1>=380)||(y1<=440)||(y1>=660))
{
if((x1<=1140||x1>=1220)||(y1<=440)||(y1>=660))
{
y1=y1+40;
if(y1>710)
y1=10;
}
}
}
}
}
}
}
}
ob=new mythread2(c);
ob.start();
}
if(d==37||d==38||d==39||d==40)
{
if (d == 39 )
{
c1='R';
if((x2>=1140||x2<=1040)||(y2>=320||y2<=240))
if((x2<=550||x2>=680)||(y2<=320||y2>=400))
{
if((x2<120||x2>=200)||(y2<=160||y2>=320))
{
if((x2<1060||x2>=1180)||(y2<=160||y2>=320))
{
if((x2<80||x2>=160)||(y2<=480)||(y2>=600))
{
if((x2<980||x2>=1100)||(y2<=480)||(y2>=600))
{
if((x2<200||x2>=280)||(y2<=480)||(y2>=600))
{
if((x2<1040||x2>=1220)||(y2<=480)||(y2>=600))
{
x2=x2+40;
if(x2>=1310)
x2=-10;
}
}
}
}
}
}
}
}
else if (d== 37 ) 
{
c1='L'; 
if((x2>=280||x2<=120)||(y2>=320||y2<=240))
if((x2<=620||x2>=720)||(y2<=320||y2>=400))
{ 
if((x2<=120||x2>=240)||(y2<=160||y2>=320))
{
if((x2<=1100||x2>=1220)||(y2<=160||y2>=320))
{
if((x2<=80||x2>=200)||(y2<=480)||(y2>=600))
{
if((x2<=1020||x2>=1140)||(y2<=480)||(y2>=600))
{
if((x2<=200||x2>=320)||(y2<=480)||(y2>=600))
{
if((x2<=1040||x2>=1260)||(y2<=480)||(y2>=600))
{
x2=x2-40;
if(x2<-20)
x2=1300;
}
}
}
}
}
}
}
}
else if (d== 38 ) 
{
c1='U';
if((y2>=360||y2<=240)||(x2<=160||x2>=240))
if((y2>=360||y2<=240)||(x2<=1080||x2>=1180))
if((x2<=620||x2>=680)||(y2<=320||y2>=440))
{
if((x2<=120||x2>=200)||(y2>=360||y2<=160))
{
if((x2<=1100||x2>=1180)||(y2<=160||y2>=360))
{
if((x2<=80||x2>=160)||(y2<=480)||(y2>=640))
{
if((x2<=1020||x2>=1100)||(y2<=480)||(y2>=640))
{
if((x2<=200||x2>=380)||(y2<=480)||(y2>=640))
{
if((x2<=1140||x2>=1220)||(y2<=480)||(y2>=640))
{
y2=y2-40;
if(y2<0)
y2=700;
}
}
}
}
}
}
}
}
else if (d== 40 ) 
{
c1='D';
if((y2>=320||y2<=200)||(x2<=160||x2>=240))
if((y2>=320||y2<=200)||(x2<=1080||x2>=1160))
if((x2<=620||x2>=680)||(y2<=280||y2>=400))
{ 
if((x2<=120||x2>=200)||(y2>=360||y2<=120))
{
if((x2<=1100||x2>=1180)||(y2<=120||y2>=360))
{
if((x2<=80||x2>=160)||(y2<=440)||(y2>=660))
{
if((x2<=1020||x2>=1100)||(y2<=440)||(y2>=660))
{
if((x2<=200||x2>=380)||(y2<=440)||(y2>=660))
{
if((x2<=1140||x2>=1220)||(y2<=440)||(y2>=660))
{
y2=y2+40;
if(y2>=710)
y2=10;   
}
}
}
}
}
}
}
}
ob1=new mythread10(c1);
ob1.start();
}
if(d==32)
{
if(c2=='W')
{
ob3=new mythread1(x1,y1);
ob3.start();
}
if(c2=='A')
{
ob4=new mythread4(x1,y1);
ob4.start();
}
if(c2=='S')
{
ob5=new mythread3(x1,y1);
ob5.start();
}
if(c2=='D')
{
ob6=new mythread5(x1,y1);
ob6.start();
}
}
if(d==96)
{
if(c1=='U')
{
ob8=new mythread7(x2,y2);
ob8.start();
}
if(c1=='L')
{
ob9=new mythread8(x2,y2);
ob9.start();
}
if(c1=='D')
{
ob7=new mythread6(x2,y2);
ob7.start();
}
if(c1=='R')
{
ob10=new mythread9(x2,y2);
ob10.start();
}
}
}
public void keyPressed(KeyEvent e)
{


}
public void keyTyped(KeyEvent e)
{

}
}