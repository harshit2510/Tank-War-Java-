class project
{
public static void main(String args[])
{
my ob=new my();
}
}